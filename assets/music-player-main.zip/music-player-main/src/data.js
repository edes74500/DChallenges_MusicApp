export const playlist = [
  {
    title: 'Lost in the City Lights',
    artist: 'Cosmo Sheldrake',
    thumbnail: './public/img/cover-1.png',
    url: './public/audio/lost-in-city-lights-145038.mp3',
  },
  {
    title: 'Forest Lullaby',
    artist: 'Lesfm',
    thumbnail: './public/img/cover-2.png',
    url: './public/audio/forest-lullaby-110624.mp3',
  },
];
